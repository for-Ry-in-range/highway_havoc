#include "LevelA.h"
#include "Utility.h"

#define LEVEL_WIDTH 14
#define LEVEL_HEIGHT 8

constexpr char FERRARI_FILEPATH[] = "assets/ferrari_16.png",
            TROPHY_FILEPATH[] = "assets/trophy.png",
            WHITE_FILEPATH[] = "assets/white_car.png",
            BLUE_FILEPATH[] = "assets/blue_car.png",
            CHARACTERS_FILEPATH[] = "assets/characters.png",
            TAXI_FILEPATH[]       = "assets/taxi.png";

unsigned int LEVELA_DATA[] =
{
    5, 3, 3, 0, 0, 0, 0, 0, 4, 4, 0, 0, 1, 0,
    5, 3, 3, 0, 0, 2, 0, 0, 4, 4, 0, 0, 0, 0,
    5, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 2, 0, 0, 5, 5, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 1, 0,
    3, 4, 4, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0,
    3, 4, 4, 0, 0, 0, 0, 0, 3, 3, 0, 0, 1, 0,
    3, 4, 4, 0, 0, 2, 0, 0, 3, 3, 0, 0, 0, 0
};

LevelA::~LevelA()
{
    delete [] m_game_state.enemies;
    delete    m_game_state.player;
    delete    m_game_state.map;
    Mix_FreeChunk(m_game_state.crash_sfx);
    Mix_FreeMusic(m_game_state.bgm);
}

void LevelA::initialise()
{
    GLuint map_texture_id = Utility::load_texture("assets/map.png");
    m_game_state.map = new Map(LEVEL_WIDTH, LEVEL_HEIGHT, LEVELA_DATA, map_texture_id, 1.0f, 6, 1);
    
    GLuint player_texture_id = Utility::load_texture(FERRARI_FILEPATH);

    int player_walking_animation[4][4] =
        {
            { 1, 5, 9, 13 }, 
            { 3, 7, 11, 15 },
            { 2, 6, 10, 14 },
            { 0, 4, 8, 12 }
        };

    m_game_state.player = new Entity(
        player_texture_id,         // texture id
        5.0f,                      // speed
        5.0f,                      // jumping power
        player_walking_animation,  // animation index sets
        0.0f,                      // animation time
        4,                         // animation frame amount
        0,                         // current animation index
        4,                         // animation column amount
        4,                         // animation row amount
        0.9f,                      // width
        0.5f,                       // height
        PLAYER
    );
    
    m_game_state.player->set_position(glm::vec3(1.0f, -3.5f, 0.0f));
    
    /**
     Enemies' stuff */
    GLuint white_texture_id = Utility::load_texture(WHITE_FILEPATH);
    GLuint taxi_texture_id = Utility::load_texture(TAXI_FILEPATH);
    GLuint blue_texture_id = Utility::load_texture(BLUE_FILEPATH);

    m_game_state.enemies = new Entity[ENEMY_COUNT];
    
    m_game_state.enemies[0] =  Entity(white_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, WALKER, IDLE);
    m_game_state.enemies[0].set_position(glm::vec3(6.5f, 3.0f, 0.0f));
    m_game_state.enemies[0].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[0].set_speed(1.5f);
    m_game_state.enemies[0].set_down(true);
    
    m_game_state.enemies[1] =  Entity(taxi_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, WALKER, IDLE);
    m_game_state.enemies[1].set_position(glm::vec3(3.4f, -6.0f, 0.0f));
    m_game_state.enemies[1].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[1].set_speed(1.5f);
    
    m_game_state.enemies[2] =  Entity(blue_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, WALKER, IDLE);
    m_game_state.enemies[2].set_position(glm::vec3(10.5f, 3.0f, 0.0f));
    m_game_state.enemies[2].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[2].set_speed(3.0f);
    m_game_state.enemies[2].set_down(true);
    
    m_game_state.enemies[3] =  Entity(taxi_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, WALKER, IDLE);
    m_game_state.enemies[3].set_position(glm::vec3(13.3f, -8.0f, 0.0f));
    m_game_state.enemies[3].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[3].set_speed(3.0f);
    
    
    


    /**
     BGM and SFX
     */
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    
    m_game_state.bgm = Mix_LoadMUS("assets/fast_instrumental.mp3");
    Mix_PlayMusic(m_game_state.bgm, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
    
    m_game_state.crash_sfx = Mix_LoadWAV("assets/crash.wav");
    
    m_game_state.cheer_sfx = Mix_LoadWAV("assets/airhorn.wav");
    
    m_game_state.death_sfx = Mix_LoadWAV("assets/car_to_car.wav");
}

void LevelA::update(float delta_time)
{
    for (int i = 0; i < m_number_of_enemies; i++) {
        if (m_game_state.player->check_collision(&m_game_state.enemies[i])) {
            lives--;
            m_game_state.player->set_position(glm::vec3(1, -3.5, 0));
            Mix_PlayChannel(-1,  m_game_state.death_sfx, 0);
        }
        else if (m_game_state.player->collided_enemy) {
            lives--;
            m_game_state.player->collided_enemy = false;
            m_game_state.player->set_position(glm::vec3(1, -3.5, 0));
            Mix_PlayChannel(-1,  m_game_state.death_sfx, 0);
        }
    }
    
    if (m_game_state.player->get_crash()) {
        Mix_PlayChannel(-1,  m_game_state.crash_sfx, 0);
        m_game_state.player->set_crash(false);
    }
    
    if (m_game_state.enemies[0].get_position().y < -8.0f) {
        m_game_state.enemies[0].set_position(glm::vec3(6.5f, 3.0f, 0.0f));
    }
    
    if (m_game_state.enemies[1].get_position().y > 2.5f) {
        m_game_state.enemies[1].set_position(glm::vec3(3.4f, -8.0f, 0.0f));
    }
    
    if (m_game_state.enemies[2].get_position().y < -8.0f) {
        m_game_state.enemies[2].set_position(glm::vec3(10.5f, 3.0f, 0.0f));
    }
    if (m_game_state.enemies[3].get_position().y > 2.5f) {
        m_game_state.enemies[3].set_position(glm::vec3(13.3f, -8.0f, 0.0f));
    }
    
    if (m_game_state.player->collided_trophy == true) {
        touched_trophy = true;
        m_game_state.player->collided_trophy = false;
    }

    m_game_state.player->update(delta_time, m_game_state.player, m_game_state.enemies, ENEMY_COUNT, m_game_state.map);
    
    for (int i = 0; i < ENEMY_COUNT; i++)
    {
        m_game_state.enemies[i].update(delta_time, m_game_state.player, NULL, 0, m_game_state.map);
    }
}


void LevelA::render(ShaderProgram *g_shader_program)
{
    m_game_state.map->render(g_shader_program);
    m_game_state.player->render(g_shader_program);
    for (int i = 0; i < m_number_of_enemies; i++)
            m_game_state.enemies[i].render(g_shader_program);
    
    GLuint chars_texture_id = Utility::load_texture(CHARACTERS_FILEPATH);
    
    if (m_game_state.player->get_position().x > 5) {
        Utility::draw_text(g_shader_program, chars_texture_id, ("LIVES: "+std::to_string(lives)), 0.5f, -0.3f, glm::vec3((m_game_state.player->get_position().x+3.2f), -0.4f, 0.0f));
    }
    else {
        Utility::draw_text(g_shader_program, chars_texture_id, ("LIVES: "+std::to_string(lives)), 0.5f, -0.3f, glm::vec3(8.2f, -0.4f, 0.0f));
    }

    glm::mat4 transform = glm::mat4(1.0f);
    transform = glm::translate(transform, glm::vec3(18.45f, -1.0f, 0.0f));
    transform = glm::rotate(transform, glm::radians(-90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    Utility::draw_text(g_shader_program, chars_texture_id, "FINISH LINE", 0.9f, -.35f, transform);
}
