#include "Lose.h"
#include "Utility.h"

#define LEVEL_WIDTH 14
#define LEVEL_HEIGHT 8

constexpr char CHARACTERS_FILEPATH[] = "assets/characters.png",
               ASTRONAUT_FILEPATH[] = "assets/astronaut_16.png";

Lose::~Lose()
{
    delete [] m_game_state.enemies;
    delete    m_game_state.player;
    delete    m_game_state.map;
    Mix_FreeChunk(m_game_state.crash_sfx);
    Mix_FreeMusic(m_game_state.bgm);
}

void Lose::initialise()
{
    
    
    int player_walking_animation[4][4] =
        {
            { 1, 5, 9, 13 },
            { 3, 7, 11, 15 },
            { 2, 6, 10, 14 },
            { 0, 4, 8, 12 }
        };

    GLuint player_texture_id = Utility::load_texture(ASTRONAUT_FILEPATH);

    m_game_state.player = new Entity(
        player_texture_id,         // texture id
        5.0f,                      // speed
        5.0f,                      // jumping power
        player_walking_animation,  // animation index sets
        0.0f,                      // animation time
        4,                         // animation frame amount
        0,                         // current animation index
        4,                         // animation column amount
        4,                         // animation row amount
        0.6f,                      // width
        0.8f,                       // height
        PLAYER
    );
    
    m_game_state.player->set_position(glm::vec3(1.0f, 0.0f, 0.0f));
    
    /**
     Enemies' stuff */

    m_game_state.enemies = new Entity[ENEMY_COUNT];
    
    /**
     BGM and SFX
     */
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    
    m_game_state.bgm = Mix_LoadMUS("assets/fast_instrumental.mp3");
    Mix_PlayMusic(m_game_state.bgm, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
}

void Lose::update(float delta_time)
{
    std::cout<<"losing screen"<<std::endl;
}


void Lose::render(ShaderProgram *g_shader_program)
{
    GLuint chars_texture_id = Utility::load_texture(CHARACTERS_FILEPATH);

    Utility::draw_text(g_shader_program, chars_texture_id, "You lost.", 0.5f, 0.03f,
              glm::vec3(2.9f, -3.5f, 0.0f));
}
